<!DOCTYPE html>
<html lang="en">
   <head>
      <link href="css/load.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
      <link rel="stylesheet" href="assets/css/style.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/css/lightbox.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
      <style>
         .body { 
         padding-top:50px;
         }
         .navbar-inverse .navbar-nav > li > a { 
         color: #DBE4E1;
         }
         .photo-gallery {
         color:#313437;
         background-color:#fff;
         }
         .photo-gallery p {
         color:#7d8285;
         }
         .photo-gallery h2 {
         font-weight:bold;
         margin-bottom:40px;
         padding-top:40px;
         color:inherit;
         }
         @media (max-width:767px) {
         .photo-gallery h2 {
         margin-bottom:25px;
         padding-top:25px;
         font-size:24px;
         }
         }
         .photo-gallery .intro {
         font-size:16px;
         max-width:500px;
         margin:0 auto 40px;
         }
         .photo-gallery .intro p {
         margin-bottom:0;
         }
         .photo-gallery .photos {
         padding-bottom:20px;
         }
         .photo-gallery .item {
         padding-bottom:30px;
         }
         .img {
         position: relative;
         z-index: 2;
         padding: 10px;
         height: auto;
         width:20%;
         flex-flow: row wrap;
         justify-content: space-between;
         transition: all 0.5s ease-in-out;
         transform: translateZ(0);
         width:30%;
         }
         @media only screen and (max-width: 600px){
         .img {
         position: relative;
         z-index: 2;
         padding: 10px;
         height: 350px;
         width: cover;
         flex-flow: row wrap;
         column:1;
         /* justify-content: space-between; */
         /* transition: all 0.5s ease-in-out; */
         /* transform: translateZ(0); */
         width: 50%;}}
         .gallery {
         position: relative;
         z-index: 2;
         padding: 10px;
         display: flex;
         flex-flow: row wrap;
         justify-content: space-between;
         transition: all 0.5s ease-in-out;
         transform: translateZ(0);
         }
         .gallery.pop {
         filter: blur(10px);
         }
         .gallery figure {
         flex-basis: 33.333%;
         padding: 10px;
         overflow: hidden;
         cursor: pointer;
         }
         .gallery figure img {
         width: 100%;
         transition: all 0.3s ease-in-out;
         }
         .gallery figure figcaption {
         display: none;
         }
         .popup {
         position: fixed;
         z-index: 2;
         top: 0;
         left: 0;
         width: 100%;
         height: 100vh;
         background: #fff;
         opacity: 0;
         transition: opacity 0.5s ease-in-out 0.2s;
         }
         .popup.pop {
         opacity: 1;
         transition: opacity 0.2s ease-in-out 0s;
         }
         .popup.pop figure {
         margin-top: 0;
         opacity: 1;
         }
         .popup figure {
         position: absolute;
         top: 50%;
         left: 50%;
         transform: translate(-50%, -50%);
         transform-origin: 0 0;
         margin-top: 30px;
         opacity: 0;
         animation: poppy 500ms linear both;
         }
         .popup figure img {
         position: relative;
         z-index: 2;
         }
         .popup figure figcaption {
         position: absolute;
         bottom: 50px;
         background: linear-gradient(180deg, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.78));
         z-index: 2;
         width: 100%;
         padding: 100px 20px 20px 20px;
         color: #fff;
         font-family: 'Open Sans', sans-serif;
         font-size: 32px;
         }
         .popup figure figcaption small {
         font-size: 11px;
         display: block;
         text-transform: uppercase;
         margin-top: 12px;
         text-indent: 3px;
         opacity: 0.7;
         letter-spacing: 1px;
         }
         .popup figure .shadow {
         position: relative;
         z-index: 1;
         top: -56px;
         margin: 0 auto;
         background-position: center bottom;
         background-repeat: no-repeat;
         width: 98%;
         height: 50px;
         opacity: 0.9;
         filter: blur(16px) contrast(1.5);
         transform: scale(0.95, -0.7);
         transform-origin: center bottom;
         }
         .popup .close {
         position: absolute;
         z-index: 3;
         top: 10px;
         right: 10px;
         width: 25px;
         height: 25px;
         cursor: pointer;
         background: url(#close);
         border-radius: 25px;
         background: rgba(0, 0, 0, .1);
         box-shadow: 0 0 3px rgba(0, 0, 0, .2);
         }
         .popup .close svg {
         width: 100%;
         height: 100%;
         }
         @keyframes poppy {
         0% {
         transform: matrix3d(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
         }
         3.4% {
         transform: matrix3d(0.316, 0, 0, 0, 0, 0.407, 0, 0, 0, 0, 1, 0, -94.672, -91.573, 0, 1);
         }
         4.3% {
         transform: matrix3d(0.408, 0, 0, 0, 0, 0.54, 0, 0, 0, 0, 1, 0, -122.527, -121.509, 0, 1);
         }
         4.7% {
         transform: matrix3d(0.45, 0, 0, 0, 0, 0.599, 0, 0, 0, 0, 1, 0, -134.908, -134.843, 0, 1);
         }
         6.81% {
         transform: matrix3d(0.659, 0, 0, 0, 0, 0.893, 0, 0, 0, 0, 1, 0, -197.77, -200.879, 0, 1);
         }
         8.61% {
         transform: matrix3d(0.82, 0, 0, 0, 0, 1.097, 0, 0, 0, 0, 1, 0, -245.972, -246.757, 0, 1);
         }
         9.41% {
         transform: matrix3d(0.883, 0, 0, 0, 0, 1.168, 0, 0, 0, 0, 1, 0, -265.038, -262.804, 0, 1);
         }
         10.21% {
         transform: matrix3d(0.942, 0, 0, 0, 0, 1.226, 0, 0, 0, 0, 1, 0, -282.462, -275.93, 0, 1);
         }
         12.91% {
         transform: matrix3d(1.094, 0, 0, 0, 0, 1.328, 0, 0, 0, 0, 1, 0, -328.332, -298.813, 0, 1);
         }
         13.61% {
         transform: matrix3d(1.123, 0, 0, 0, 0, 1.332, 0, 0, 0, 0, 1, 0, -336.934, -299.783, 0, 1);
         }
         14.11% {
         transform: matrix3d(1.141, 0, 0, 0, 0, 1.331, 0, 0, 0, 0, 1, 0, -342.273, -299.395, 0, 1);
         }
         17.22% {
         transform: matrix3d(1.205, 0, 0, 0, 0, 1.252, 0, 0, 0, 0, 1, 0, -361.606, -281.592, 0, 1);
         }
         17.52% {
         transform: matrix3d(1.208, 0, 0, 0, 0, 1.239, 0, 0, 0, 0, 1, 0, -362.348, -278.88, 0, 1);
         }
         18.72% {
         transform: matrix3d(1.212, 0, 0, 0, 0, 1.187, 0, 0, 0, 0, 1, 0, -363.633, -267.15, 0, 1);
         }
         21.32% {
         transform: matrix3d(1.196, 0, 0, 0, 0, 1.069, 0, 0, 0, 0, 1, 0, -358.864, -240.617, 0, 1);
         }
         24.32% {
         transform: matrix3d(1.151, 0, 0, 0, 0, 0.96, 0, 0, 0, 0, 1, 0, -345.164, -216.073, 0, 1);
         }
         25.23% {
         transform: matrix3d(1.134, 0, 0, 0, 0, 0.938, 0, 0, 0, 0, 1, 0, -340.193, -210.948, 0, 1);
         }
         28.33% {
         transform: matrix3d(1.075, 0, 0, 0, 0, 0.898, 0, 0, 0, 0, 1, 0, -322.647, -202.048, 0, 1);
         }
         29.03% {
         transform: matrix3d(1.063, 0, 0, 0, 0, 0.897, 0, 0, 0, 0, 1, 0, -318.884, -201.771, 0, 1);
         }
         29.93% {
         transform: matrix3d(1.048, 0, 0, 0, 0, 0.899, 0, 0, 0, 0, 1, 0, -314.277, -202.202, 0, 1);
         }
         35.54% {
         transform: matrix3d(0.979, 0, 0, 0, 0, 0.962, 0, 0, 0, 0, 1, 0, -293.828, -216.499, 0, 1);
         }
         36.74% {
         transform: matrix3d(0.972, 0, 0, 0, 0, 0.979, 0, 0, 0, 0, 1, 0, -291.489, -220.242, 0, 1);
         }
         39.44% {
         transform: matrix3d(0.962, 0, 0, 0, 0, 1.01, 0, 0, 0, 0, 1, 0, -288.62, -227.228, 0, 1);
         }
         41.04% {
         transform: matrix3d(0.961, 0, 0, 0, 0, 1.022, 0, 0, 0, 0, 1, 0, -288.247, -229.999, 0, 1);
         }
         44.44% {
         transform: matrix3d(0.966, 0, 0, 0, 0, 1.032, 0, 0, 0, 0, 1, 0, -289.763, -232.215, 0, 1);
         }
         52.15% {
         transform: matrix3d(0.991, 0, 0, 0, 0, 1.006, 0, 0, 0, 0, 1, 0, -297.363, -226.449, 0, 1);
         }
         59.86% {
         transform: matrix3d(1.006, 0, 0, 0, 0, 0.99, 0, 0, 0, 0, 1, 0, -301.813, -222.759, 0, 1);
         }
         61.66% {
         transform: matrix3d(1.007, 0, 0, 0, 0, 0.991, 0, 0, 0, 0, 1, 0, -302.102, -222.926, 0, 1);
         }
         63.26% {
         transform: matrix3d(1.007, 0, 0, 0, 0, 0.992, 0, 0, 0, 0, 1, 0, -302.171, -223.276, 0, 1);
         }
         75.28% {
         transform: matrix3d(1.001, 0, 0, 0, 0, 1.003, 0, 0, 0, 0, 1, 0, -300.341, -225.696, 0, 1);
         }
         83.98% {
         transform: matrix3d(0.999, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, -299.61, -225.049, 0, 1);
         }
         85.49% {
         transform: matrix3d(0.999, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, -299.599, -224.94, 0, 1);
         }
         90.69% {
         transform: matrix3d(0.999, 0, 0, 0, 0, 0.999, 0, 0, 0, 0, 1, 0, -299.705, -224.784, 0, 1);
         }
         100% {
         transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, -300, -225, 0, 1);
         }
         }
         .banner{
         width:100%;
         height:300px;
         background-color:red;
         }
         @media only screen and (max-width:400px) {
         .gallery {
         position: relative;
         z-index: 2;
         padding: 10px;
         display: flex;
         flex-wrap: nowrap | wrap | wrap-reverse;
         flex-grow: 1;
         flex-flow: row wrap;
         justify-content: space-between;
         transition: all 0.5s ease-in-out;
         transform: translateZ(0);
         }
         .gallery figure {
         flex-basis: 100%;
         padding: 10px;
         overflow: hidden;
         cursor: pointer;
         }
         .gallery figure {
         flex-basis: 100%;
         padding: 10px;
         overflow: hidden;
         cursor: pointer;
         }
         .img {
         position: relative;
         z-index: 2;
         padding: 10px;
         height: 350px;
         width: cover;
         flex-flow: row wrap;
         justify-content: space-between;
         transition: all 0.5s ease-in-out;
         transform: translateZ(0);
         width: 100%;
         }}
         .form{
         color: yellow;
         }
         .centroupload{
         align-content:center;
         padding-top:122px;
         padding-left:300px;
         }.body { 
         padding-top:50px;
         }
         .navbar-inverse .navbar-nav > li > a { 
         color: #DBE4E1;
         }
         .img {
         position: relative;
         z-index: 2;
         padding: 10px;
         height: auto;
         width:20%;
         flex-flow: row wrap;
         justify-content: space-between;
         transition: all 0.5s ease-in-out;
         transform: translateZ(0);
         width:30%;
         }
         @media only screen and (max-width: 600px){
         .img {
         position: relative;
         z-index: 2;
         padding: 10px;
         height: 350px;
         width: cover;
         flex-flow: row wrap;
         column:1;
         /* justify-content: space-between; */
         /* transition: all 0.5s ease-in-out; */
         /* transform: translateZ(0); */
         width: 50%;}}
         .gallery {
         position: relative;
         z-index: 2;
         padding: 10px;
         display: flex;
         flex-flow: row wrap;
         justify-content: space-between;
         transition: all 0.5s ease-in-out;
         transform: translateZ(0);
         }
         .gallery.pop {
         filter: blur(10px);
         }
         .gallery figure {
         flex-basis: 33.333%;
         padding: 10px;
         overflow: hidden;
         cursor: pointer;
         }
         .gallery figure img {
         width: 100%;
         transition: all 0.3s ease-in-out;
         }
         .gallery figure figcaption {
         display: none;
         }
         .popup {
         position: fixed;
         z-index: 2;
         top: 0;
         left: 0;
         width: 100%;
         height: 100vh;
         background: #fff;
         opacity: 0;
         transition: opacity 0.5s ease-in-out 0.2s;
         }
         .popup.pop {
         opacity: 1;
         transition: opacity 0.2s ease-in-out 0s;
         }
         .popup.pop figure {
         margin-top: 0;
         opacity: 1;
         }
         .popup figure {
         position: absolute;
         top: 50%;
         left: 50%;
         transform: translate(-50%, -50%);
         transform-origin: 0 0;
         margin-top: 30px;
         opacity: 0;
         animation: poppy 500ms linear both;
         }
         .popup figure img {
         position: relative;
         z-index: 2;
         }
         .popup figure figcaption {
         position: absolute;
         bottom: 50px;
         background: linear-gradient(180deg, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.78));
         z-index: 2;
         width: 100%;
         padding: 100px 20px 20px 20px;
         color: #fff;
         font-family: 'Open Sans', sans-serif;
         font-size: 32px;
         }
         .popup figure figcaption small {
         font-size: 11px;
         display: block;
         text-transform: uppercase;
         margin-top: 12px;
         text-indent: 3px;
         opacity: 0.7;
         letter-spacing: 1px;
         }
         .popup figure .shadow {
         position: relative;
         z-index: 1;
         top: -56px;
         margin: 0 auto;
         background-position: center bottom;
         background-repeat: no-repeat;
         width: 98%;
         height: 50px;
         opacity: 0.9;
         filter: blur(16px) contrast(1.5);
         transform: scale(0.95, -0.7);
         transform-origin: center bottom;
         }
         .popup .close {
         position: absolute;
         z-index: 3;
         top: 10px;
         right: 10px;
         width: 25px;
         height: 25px;
         cursor: pointer;
         background: url(#close);
         border-radius: 25px;
         background: rgba(0, 0, 0, .1);
         box-shadow: 0 0 3px rgba(0, 0, 0, .2);
         }
         .popup .close svg {
         width: 100%;
         height: 100%;
         }
         @keyframes poppy {
         0% {
         transform: matrix3d(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
         }
         3.4% {
         transform: matrix3d(0.316, 0, 0, 0, 0, 0.407, 0, 0, 0, 0, 1, 0, -94.672, -91.573, 0, 1);
         }
         4.3% {
         transform: matrix3d(0.408, 0, 0, 0, 0, 0.54, 0, 0, 0, 0, 1, 0, -122.527, -121.509, 0, 1);
         }
         4.7% {
         transform: matrix3d(0.45, 0, 0, 0, 0, 0.599, 0, 0, 0, 0, 1, 0, -134.908, -134.843, 0, 1);
         }
         6.81% {
         transform: matrix3d(0.659, 0, 0, 0, 0, 0.893, 0, 0, 0, 0, 1, 0, -197.77, -200.879, 0, 1);
         }
         8.61% {
         transform: matrix3d(0.82, 0, 0, 0, 0, 1.097, 0, 0, 0, 0, 1, 0, -245.972, -246.757, 0, 1);
         }
         9.41% {
         transform: matrix3d(0.883, 0, 0, 0, 0, 1.168, 0, 0, 0, 0, 1, 0, -265.038, -262.804, 0, 1);
         }
         10.21% {
         transform: matrix3d(0.942, 0, 0, 0, 0, 1.226, 0, 0, 0, 0, 1, 0, -282.462, -275.93, 0, 1);
         }
         12.91% {
         transform: matrix3d(1.094, 0, 0, 0, 0, 1.328, 0, 0, 0, 0, 1, 0, -328.332, -298.813, 0, 1);
         }
         13.61% {
         transform: matrix3d(1.123, 0, 0, 0, 0, 1.332, 0, 0, 0, 0, 1, 0, -336.934, -299.783, 0, 1);
         }
         14.11% {
         transform: matrix3d(1.141, 0, 0, 0, 0, 1.331, 0, 0, 0, 0, 1, 0, -342.273, -299.395, 0, 1);
         }
         17.22% {
         transform: matrix3d(1.205, 0, 0, 0, 0, 1.252, 0, 0, 0, 0, 1, 0, -361.606, -281.592, 0, 1);
         }
         17.52% {
         transform: matrix3d(1.208, 0, 0, 0, 0, 1.239, 0, 0, 0, 0, 1, 0, -362.348, -278.88, 0, 1);
         }
         18.72% {
         transform: matrix3d(1.212, 0, 0, 0, 0, 1.187, 0, 0, 0, 0, 1, 0, -363.633, -267.15, 0, 1);
         }
         21.32% {
         transform: matrix3d(1.196, 0, 0, 0, 0, 1.069, 0, 0, 0, 0, 1, 0, -358.864, -240.617, 0, 1);
         }
         24.32% {
         transform: matrix3d(1.151, 0, 0, 0, 0, 0.96, 0, 0, 0, 0, 1, 0, -345.164, -216.073, 0, 1);
         }
         25.23% {
         transform: matrix3d(1.134, 0, 0, 0, 0, 0.938, 0, 0, 0, 0, 1, 0, -340.193, -210.948, 0, 1);
         }
         28.33% {
         transform: matrix3d(1.075, 0, 0, 0, 0, 0.898, 0, 0, 0, 0, 1, 0, -322.647, -202.048, 0, 1);
         }
         29.03% {
         transform: matrix3d(1.063, 0, 0, 0, 0, 0.897, 0, 0, 0, 0, 1, 0, -318.884, -201.771, 0, 1);
         }
         29.93% {
         transform: matrix3d(1.048, 0, 0, 0, 0, 0.899, 0, 0, 0, 0, 1, 0, -314.277, -202.202, 0, 1);
         }
         35.54% {
         transform: matrix3d(0.979, 0, 0, 0, 0, 0.962, 0, 0, 0, 0, 1, 0, -293.828, -216.499, 0, 1);
         }
         36.74% {
         transform: matrix3d(0.972, 0, 0, 0, 0, 0.979, 0, 0, 0, 0, 1, 0, -291.489, -220.242, 0, 1);
         }
         39.44% {
         transform: matrix3d(0.962, 0, 0, 0, 0, 1.01, 0, 0, 0, 0, 1, 0, -288.62, -227.228, 0, 1);
         }
         41.04% {
         transform: matrix3d(0.961, 0, 0, 0, 0, 1.022, 0, 0, 0, 0, 1, 0, -288.247, -229.999, 0, 1);
         }
         44.44% {
         transform: matrix3d(0.966, 0, 0, 0, 0, 1.032, 0, 0, 0, 0, 1, 0, -289.763, -232.215, 0, 1);
         }
         52.15% {
         transform: matrix3d(0.991, 0, 0, 0, 0, 1.006, 0, 0, 0, 0, 1, 0, -297.363, -226.449, 0, 1);
         }
         59.86% {
         transform: matrix3d(1.006, 0, 0, 0, 0, 0.99, 0, 0, 0, 0, 1, 0, -301.813, -222.759, 0, 1);
         }
         61.66% {
         transform: matrix3d(1.007, 0, 0, 0, 0, 0.991, 0, 0, 0, 0, 1, 0, -302.102, -222.926, 0, 1);
         }
         63.26% {
         transform: matrix3d(1.007, 0, 0, 0, 0, 0.992, 0, 0, 0, 0, 1, 0, -302.171, -223.276, 0, 1);
         }
         75.28% {
         transform: matrix3d(1.001, 0, 0, 0, 0, 1.003, 0, 0, 0, 0, 1, 0, -300.341, -225.696, 0, 1);
         }
         83.98% {
         transform: matrix3d(0.999, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, -299.61, -225.049, 0, 1);
         }
         85.49% {
         transform: matrix3d(0.999, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, -299.599, -224.94, 0, 1);
         }
         90.69% {
         transform: matrix3d(0.999, 0, 0, 0, 0, 0.999, 0, 0, 0, 0, 1, 0, -299.705, -224.784, 0, 1);
         }
         100% {
         transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, -300, -225, 0, 1);
         }
         }
         .banner{
         width:100%;
         height:300px;
         background-color:red;
         }
         @media only screen and (max-width:400px) {
         .gallery {
         position: relative;
         z-index: 2;
         padding: 10px;
         display: flex;
         flex-wrap: nowrap | wrap | wrap-reverse;
         flex-grow: 1;
         flex-flow: row wrap;
         justify-content: space-between;
         transition: all 0.5s ease-in-out;
         transform: translateZ(0);
         }
         .gallery figure {
         flex-basis: 100%;
         padding: 10px;
         overflow: hidden;
         cursor: pointer;
         }
         .gallery figure {
         flex-basis: 100%;
         padding: 10px;
         overflow: hidden;
         cursor: pointer;
         }
         .img {
         position: relative;
         z-index: 2;
         padding: 10px;
         height: 350px;
         width: cover;
         flex-flow: row wrap;
         justify-content: space-between;
         transition: all 0.5s ease-in-out;
         transform: translateZ(0);
         width: 100%;
         }}
         .form{
         color: yellow;
         }
         .centroupload{
         align-content:center;
         }


         .dropzone {
  margin-bottom: 1rem;
}
.dropzone--actual {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 3rem;
  border: 0.125rem dashed #000;
  border-radius: 0.125rem;
}
.dropzone--actual .dropzone__label {
  margin-bottom: 0;
}
.dropzone--actual .dropzone__label::after {
  content: '';
}
.dropzone--actual .dropzone__label--focused {
  outline: 0;
  box-shadow: 0 0 0.0625rem 0.25rem #5e9ed6;
}
.dropzone--actual .dropzone__file {
  position: absolute;
  left: -9999em;
}
.dropzone--actual .dropzone__upload {
  display: none;
}
.dropzone--dragover {
  background-color: #ddd;
}
.dropzone__label {
  display: inline-block;
  margin-bottom: 0.5rem;
}
.dropzone__label::after {
  content: ':';
}
.dropzone__file {
  display: block;
  padding: 0.375rem 0.75rem;
  border: 0.0625rem solid #000;
  border-radius: 0.125rem;
  font-family: inherit;
  font-size: inherit;
}
.dropzone__upload {
  margin-top: 0.5rem;
}






      </style>
      <!--[if IE]>
      <script src="https://cdn.jsdelivr.net/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://cdn.jsdelivr.net/respond/1.4.2/respond.min.js"></script>
      <![endif]-->
   </head>
</html>
<body>



<div class="dropzone" data-dropzone>
      <div class="dropzone__field">
        <label class="dropzone__label" for="files" data-dropzone-label>Upload files</label>
        <input class="dropzone__file" id="files" name="files" type="file" multiple data-dropzone-file>
      </div>
      <button class="dropzone__upload button" name="uploadFile" type="submit">Upload files</button>
    </div>
    <button class="button" name="continue" type="submit">Continue</button>
  </form>
</section>
























   <div class="banner">
      <div class="container">
         <div class="upform">
            <?php if(!empty($statusMsg)){?>
            <p class="status-msg"><?php echo $statusMsg;?></p>
            <?php } ?>
         </div>
         <div class="centroupload">
            <form action="upload.php" method="post" enctype="multipart/form-data" class="botton">
               Select Image File to Upload:
               <input type="file" name="file" class="btn btn-outline-info">
               <input type="submit" name="submit" value="Upload" class="btn btn-primary btn-lg" >
               
      <span id="file-upload-btn" class="btn btn-primary">Select a file</span>
         </div>
      </div>
      </form>
   </div>
   </div>    <div class="dropzone" data-dropzone>
      <div class="dropzone__field">

   <div class="gallery">
   <div class="gcon">
   <h2>upload image</h2>
   <div class="photo-gallery">
      <div class="container">
         <div class="row photos">
            <?php
               // Include the database configuration file
               include 'dbConfig.php';
               $query = $db->query("SELECT * FROM images ORDER BY uploaded_on DESC");
               
               if($query->num_rows > 0){
                   while($row = $query->fetch_assoc()){
                       $imageURL = 'uploads/'.$row["file_name"];
               ?>
            <img src="<?php echo $imageURL; ?>" alt=""  class="col-sm-6 col-md-4 col-lg-3 item" />
            <?php }
               }else{ ?>
            <p>No image(s) found...</p>
            <?php } ?>
         </div>
      </div>
   </div></div>
   </div>
</body>
</html>
<?php
   include 'upload.php';
   $url=$_SERVER['REQUEST_URI'];
      header("Refresh: 10; URL=$url");
   ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/js/lightbox.min.js"></script>
<script>
   $(document).on("click", '[data-toggle="lightbox"]', function(event) {
     event.preventDefault();
     $(this).ekkoLightbox();
   });
   
</script>
<script>
   $(document).ready(function(){
       // File upload via Ajax
       $("#uploadForm").on('submit', function(e){
           e.preventDefault();
           $.ajax({
               type: 'POST',
               url: 'upload.php',
               data: new FormData(this),
               contentType: false,
               cache: false,
               processData:false,
               beforeSend: function(){
                   $('#uploadStatus').html('<img src="images/uploading.gif"/>');
               },
               error:function(){
                   $('#uploadStatus').html('<span style="color:#EA4335;">Images upload failed, please try again.<span>');
               },
               success: function(data){
                   $('#uploadForm')[0].reset();
                   $('#uploadStatus').html('<span style="color:#28A74B;">Images uploaded successfully.<span>');
                   $('.gallery').html(data);
               }
           });
       });
       
       // File type validation
       $("#fileInput").change(function(){
           var fileLength = this.files.length;
           var match= ["image/jpeg","image/png","image/jpg","image/gif"];
           var i;
           for(i = 0; i < fileLength; i++){ 
               var file = this.files[i];
               var imagefile = file.type;
               if(!((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2]) || (imagefile==match[3]))){
                   alert('Please select a valid image file (JPEG/JPG/PNG/GIF).');
                   $("#fileInput").val('');
                   return false;
               }
           }
       });
   });
</script>
<script>
   $(document).on("click", '[data-toggle="lightbox"]', function(event) {
     event.preventDefault();
     $(this).ekkoLightbox();
   });
   // Gallery image hover
   $( ".img-wrapper" ).hover(
     function() {
       $(this).find(".img-overlay").animate({opacity: 1}, 600);
     }, function() {
       $(this).find(".img-overlay").animate({opacity: 0}, 600);
     }
   );
   
   // Lightbox
   var $overlay = $('<div id="overlay"></div>');
   var $image = $("<img>");
   var $prevButton = $('<div id="prevButton"><i class="fa fa-chevron-left"></i></div>');
   var $nextButton = $('<div id="nextButton"><i class="fa fa-chevron-right"></i></div>');
   var $exitButton = $('<div id="exitButton"><i class="fa fa-times"></i></div>');
   
   // Add overlay
   $overlay.append($image).prepend($prevButton).append($nextButton).append($exitButton);
   $("#gallery").append($overlay);
   
   // Hide overlay on default
   $overlay.hide();
   
   // When an image is clicked
   $(".img-overlay").click(function(event) {
     // Prevents default behavior
     event.preventDefault();
     // Adds href attribute to variable
     var imageLocation = $(this).prev().attr("href");
     // Add the image src to $image
     $image.attr("src", imageLocation);
     // Fade in the overlay
     $overlay.fadeIn("slow");
   });
   
   // When the overlay is clicked
   $overlay.click(function() {
     // Fade out the overlay
     $(this).fadeOut("slow");
   });
   
   // When next button is clicked
   $nextButton.click(function(event) {
     // Hide the current image
     $("#overlay img").hide();
     // Overlay image location
     var $currentImgSrc = $("#overlay img").attr("src");
     // Image with matching location of the overlay image
     var $currentImg = $('#image-gallery img[src="' + $currentImgSrc + '"]');
     // Finds the next image
     var $nextImg = $($currentImg.closest(".image").next().find("img"));
     // All of the images in the gallery
     var $images = $("#image-gallery img");
     // If there is a next image
     if ($nextImg.length > 0) { 
       // Fade in the next image
       $("#overlay img").attr("src", $nextImg.attr("src")).fadeIn(800);
     } else {
       // Otherwise fade in the first image
       $("#overlay img").attr("src", $($images[0]).attr("src")).fadeIn(800);
     }
     // Prevents overlay from being hidden
     event.stopPropagation();
   });
   
   // When previous button is clicked
   $prevButton.click(function(event) {
     // Hide the current image
     $("#overlay img").hide();
     // Overlay image location
     var $currentImgSrc = $("#overlay img").attr("src");
     // Image with matching location of the overlay image
     var $currentImg = $('#image-gallery img[src="' + $currentImgSrc + '"]');
     // Finds the next image
     var $nextImg = $($currentImg.closest(".image").prev().find("img"));
     // Fade in the next image
     $("#overlay img").attr("src", $nextImg.attr("src")).fadeIn(800);
     // Prevents overlay from being hidden
     event.stopPropagation();
   });
   
   // When the exit button is clicked
   $exitButton.click(function() {
     // Fade out the overlay
     $("#overlay").fadeOut("slow");
   });
   <script>
   
   
   let modalId = $('#image-gallery');
   
   $(document)
     .ready(function () {
   
       loadGallery(true, 'a.thumbnail');
   
       //This function disables buttons when needed
       function disableButtons(counter_max, counter_current) {
         $('#show-previous-image, #show-next-image')
           .show();
         if (counter_max === counter_current) {
           $('#show-next-image')
             .hide();
         } else if (counter_current === 1) {
           $('#show-previous-image')
             .hide();
         }
       }
   
       /**
        *
        * @param setIDs        Sets IDs when DOM is loaded. If using a PHP counter, set to false.
        * @param setClickAttr  Sets the attribute for the click handler.
        */
   
       function loadGallery(setIDs, setClickAttr) {
         let current_image,
           selector,
           counter = 0;
   
         $('#show-next-image, #show-previous-image')
           .click(function () {
             if ($(this)
               .attr('id') === 'show-previous-image') {
               current_image--;
             } else {
               current_image++;
             }
   
             selector = $('[data-image-id="' + current_image + '"]');
             updateGallery(selector);
           });
   
         function updateGallery(selector) {
           let $sel = selector;
           current_image = $sel.data('image-id');
           $('#image-gallery-title')
             .text($sel.data('title'));
           $('#image-gallery-image')
             .attr('src', $sel.data('image'));
           disableButtons(counter, $sel.data('image-id'));
         }
   
         if (setIDs == true) {
           $('[data-image-id]')
             .each(function () {
               counter++;
               $(this)
                 .attr('data-image-id', counter);
             });
         }
         $(setClickAttr)
           .on('click', function () {
             updateGallery($(this));
           });
       }
     });
   
   // build key actions
   $(document)
     .keydown(function (e) {
       switch (e.which) {
         case 37: // left
           if ((modalId.data('bs.modal') || {})._isShown && $('#show-previous-image').is(":visible")) {
             $('#show-previous-image')
               .click();
           }
           break;
   
         case 39: // right
           if ((modalId.data('bs.modal') || {})._isShown && $('#show-next-image').is(":visible")) {
             $('#show-next-image')
               .click();
           }
           break;
   
         default:
           return; // exit this handler for other keys
       }
       e.preventDefault(); // prevent the default action (scroll / move caret)
     });
   
</script>
<script>
let modalId = $('#image-gallery');
$(document)
.ready(function () {
loadGallery(true, 'a.thumbnail');
//This function disables buttons when needed
function disableButtons(counter_max, counter_current) {
$('#show-previous-image, #show-next-image')
.show();
if (counter_max === counter_current) {
$('#show-next-image')
.hide();
} else if (counter_current === 1) {
$('#show-previous-image')
.hide();
}
}
/**
*
* @param setIDs        Sets IDs when DOM is loaded. If using a PHP counter, set to false.
* @param setClickAttr  Sets the attribute for the click handler.
*/
function loadGallery(setIDs, setClickAttr) {
let current_image,
selector,
counter = 0;
$('#show-next-image, #show-previous-image')
.click(function () {
if ($(this)
.attr('id') === 'show-previous-image') {
current_image--;
} else {
current_image++;
}
selector = $('[data-image-id="' + current_image + '"]');
updateGallery(selector);
});
function updateGallery(selector) {
let $sel = selector;
current_image = $sel.data('image-id');
$('#image-gallery-title')
.text($sel.data('title'));
$('#image-gallery-image')
.attr('src', $sel.data('image'));
disableButtons(counter, $sel.data('image-id'));
}
if (setIDs == true) {
$('[data-image-id]')
.each(function () {
counter++;
$(this)
.attr('data-image-id', counter);
});
}
$(setClickAttr)
.on('click', function () {
updateGallery($(this));
});
}
});
// build key actions
$(document)
.keydown(function (e) {
switch (e.which) {
case 37: // left
if ((modalId.data('bs.modal') || {})._isShown && $('#show-previous-image').is(":visible")) {
$('#show-previous-image')
.click();
}
break;
case 39: // right
if ((modalId.data('bs.modal') || {})._isShown && $('#show-next-image').is(":visible")) {
$('#show-next-image')
.click();
}
break;
default:
return; // exit this handler for other keys
}
e.preventDefault(); // prevent the default action (scroll / move caret)
});
<script>